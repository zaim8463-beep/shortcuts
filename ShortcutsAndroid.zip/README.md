# Shortcuts for Android — v0.2

نسخة أندرويد من تطبيق Shortcuts بتاع الآيفون، مكتوبة بـ Kotlin + Jetpack Compose.

## 1) بناء الـ APK على GitHub
1. اعمل repository جديد فاضي على GitHub.
2. فك الـ zip وارفع **كل المحتويات** (لازم يفضل فولدر `.github/workflows` في الجذر).
3. افتح **Actions** ← **Build APK** (بيشتغل لوحده أو دوس Run workflow).
4. بعد 4–8 دقايق نزّل `shortcuts-debug-apk` من **Artifacts** وثبّت `app-debug.apk`.

لو الـ Build فشل: افتح الـ log وانسخ أول سطر فيه `error:` وابعتهولي.

## 2) المميزات
**المكتبة (Shortcuts)**: شاشة جذر (All Shortcuts / Share Sheet / Folders) · Grid أو List · بحث · Select (حذف، تكرار، نقل، تصدير) · ترتيب (الاسم / آخر تعديل / تاريخ الإنشاء / مخصص) · مجلدات · قائمة لكل Shortcut (Edit, Details, Duplicate, Add to Home Screen, Share, Move, Delete).

**المحرر**: كروت Actions بألوان الأقسام · ↑↓ لإعادة الترتيب · حذف (البلوكات بتتحذف كاملة) · **Variables**: شريط فوق الكيبورد بيحط Magic Variables كأزرار زرقا (ناتج أي Action سابق) + Ask Each Time / Clipboard / Current Date / Shortcut Input / Repeat Item / Repeat Index + متغيراتك (Set / Add to Variable).

**التحكم**: If / Otherwise · Repeat · Repeat with Each · Choose from Menu · Stop · Stop and Output · Run Shortcut (متداخل).

**~80 Action** في 9 أقسام: Scripting, Lists & Data (List, Dictionary, Filter, Sort, Get Item…), Text (Split, Combine, Replace, Regex Match, Base64, URL Encode…), Numbers (Calculate, Expression, Statistics, Round…), Dates (Format, Adjust, Time Between), Web (Get Contents of URL بـ GET/POST/Headers/JSON), Device (battery, clipboard, flashlight, volume, ringer, vibrate, settings…), Apps (Open App بالاسم، Share، Call، SMS، Email، Maps، Navigate، Timer، Alarm، Calendar Event، Contact)، Files.

**Automation**: Time of Day (يومي/أسبوعي/شهري) · Charger · Battery Level · Wi-Fi · Bluetooth · Airplane Mode · Do Not Disturb · Low Power Mode · Wired Headphones · Device Unlocked — مع **Ask Before Running** (إشعار) أو التشغيل الفوري في الخلفية.

**التكامل مع النظام**: Widget 2×2 · قائمة الضغط المطوّل على الأيقونة · Add to Home Screen · Quick Settings tiles (3) · Share Sheet · `shortcuts://` URL scheme · Import/Export (ملف أو Clipboard) · Import Questions · Gallery (6 فئات).

## 3) الفرق عن iOS (قيود أندرويد)
- لا يوجد Siri → استخدم الأيقونات/الـ Widget/الـ Tiles.
- الـ Automations بتحتاج إشعار دائم صغير (Foreground Service) وتعطيل Battery Optimization على بعض الأجهزة (من Settings داخل التطبيق).
- في التشغيل الخلفي: Ask for Input بياخد الإجابة الافتراضية، Show Result بيطلع إشعار، وأندرويد بيمنع فتح تطبيقات من الخلفية.
- مفيش حاليًا: Location triggers، NFC، Messages/Email triggers، Take Photo، Get Current Location، Run JavaScript on Webpage، iCloud sync.
- ترتيب الـ Actions بالأسهم (مش سحب).

## 4) المرحلة الجاية (لو حبيت)
Location (Arrive/Leave) · Take Photo & Files picker · سحب وإفلات للـ Actions · واجهة عربي · Release APK موقّع.
