package com.example.shortcuts

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val TokenRe = Regex("\\{\\{(.+?)\\}\\}")

fun fmtNum(d: Double): String =
    if (d.isNaN() || d.isInfinite()) d.toString()
    else if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString()
    else d.toString()

fun str(v: Any?): String = when (v) {
    null -> ""
    is String -> v
    is Double -> fmtNum(v)
    is Int -> v.toString()
    is Long -> v.toString()
    is Boolean -> if (v) "true" else "false"
    is List<*> -> v.joinToString("\n") { str(it) }
    is Map<*, *> -> try { JSONObject(v).toString() } catch (e: Exception) { v.toString() }
    else -> v.toString()
}

fun num(v: Any?): Double = when (v) {
    is Double -> v
    is Int -> v.toDouble()
    is Long -> v.toDouble()
    is Boolean -> if (v) 1.0 else 0.0
    is String -> v.trim().toDoubleOrNull() ?: 0.0
    is List<*> -> if (v.isEmpty()) 0.0 else num(v[0])
    else -> 0.0
}

fun toList(v: Any?): List<Any?> = when (v) {
    null -> emptyList()
    is List<*> -> v
    is String -> if (v.isEmpty()) emptyList() else v.split("\n")
    else -> listOf(v)
}

fun fromJson(o: Any?): Any? = when (o) {
    is JSONObject -> {
        val m = LinkedHashMap<String, Any?>()
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            m[k] = fromJson(o.opt(k))
        }
        m
    }
    is JSONArray -> (0 until o.length()).map { fromJson(o.opt(it)) }
    JSONObject.NULL -> null
    is Number -> o.toDouble()
    else -> o
}

fun parseJson(s: String): Any? = try {
    val t = s.trim()
    if (t.startsWith("[")) fromJson(JSONArray(t))
    else if (t.startsWith("{")) fromJson(JSONObject(t))
    else null
} catch (e: Exception) { null }

@Suppress("UNCHECKED_CAST")
fun dig(root: Any?, path: String): Any? {
    var cur: Any? = root
    for (k in path.split(".").filter { it.isNotEmpty() }) {
        cur = when (cur) {
            is Map<*, *> -> (cur as Map<String, Any?>)[k]
            is List<*> -> cur.getOrNull(k.toIntOrNull() ?: -1)
            else -> null
        }
    }
    return cur
}

const val ISO_PATTERN = "yyyy-MM-dd'T'HH:mm:ssXXX"

fun isoFormat(d: Date): String = SimpleDateFormat(ISO_PATTERN, Locale.US).format(d)
fun isoNow(): String = isoFormat(Date())

fun parseDate(s: String): Date? {
    val t = s.trim()
    if (t.isEmpty()) return null
    for (p in listOf(ISO_PATTERN, "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd")) {
        try { return SimpleDateFormat(p, Locale.US).parse(t) } catch (e: Exception) { }
    }
    return null
}

/** Small recursive-descent calculator: + - * / % ^ ( ) and unary minus. */
class ExprParser(src: String) {
    private val s = src.replace("×", "*").replace("÷", "/").replace(" ", "")
    private var i = 0

    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

    fun parse(): Double {
        val v = expr()
        if (i < s.length) throw IllegalArgumentException("Unexpected '${s[i]}' in expression")
        return v
    }

    private fun expr(): Double {
        var v = term()
        while (peek() == '+' || peek() == '-') {
            val op = s[i++]
            val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }

    private fun term(): Double {
        var v = power()
        while (peek() == '*' || peek() == '/' || peek() == '%') {
            val op = s[i++]
            val r = power()
            v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
        }
        return v
    }

    private fun power(): Double {
        val b = unary()
        if (peek() == '^') { i++; return Math.pow(b, power()) }
        return b
    }

    private fun unary(): Double {
        if (peek() == '-') { i++; return -unary() }
        if (peek() == '+') { i++; return unary() }
        return primary()
    }

    private fun primary(): Double {
        if (peek() == '(') {
            i++
            val v = expr()
            if (peek() == ')') i++ else throw IllegalArgumentException("Missing )")
            return v
        }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw IllegalArgumentException("Bad expression")
        return s.substring(st, i).toDouble()
    }
}

fun evalExpr(src: String): Double = ExprParser(src).parse()
