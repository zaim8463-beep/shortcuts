package com.example.shortcuts

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString().take(8)
fun newUuid(): String = UUID.randomUUID().toString()

data class Step(
    val id: String = newId(),
    val type: String,
    val params: Map<String, String> = emptyMap()
)

data class ImportQuestion(val stepId: String, val key: String, val text: String)

data class Shortcut(
    val id: String = newUuid(),
    val name: String,
    val color: Int = 6,
    val glyph: String = "⚡",
    val steps: List<Step> = emptyList(),
    val folderId: String? = null,
    val share: Boolean = false,
    val qs: Boolean = false,
    val created: Long = System.currentTimeMillis(),
    val modified: Long = System.currentTimeMillis(),
    val questions: List<ImportQuestion> = emptyList()
)

data class Folder(val id: String = newUuid(), val name: String, val glyph: String = "📁", val color: Int = 6)

data class Automation(
    val id: String = newUuid(),
    val shortcutId: String,
    val type: String,
    val params: Map<String, String> = emptyMap(),
    val enabled: Boolean = true,
    val askBefore: Boolean = true
)

val TileColors = listOf(
    0xFFE5493A, 0xFFF38A31, 0xFFF5C400, 0xFF34C759, 0xFF29B6A5, 0xFF3FB7E8,
    0xFF2F80ED, 0xFF6C5CE7, 0xFF9B59B6, 0xFFE056A0, 0xFF8E8E93, 0xFFB5874A
)

val Glyphs = listOf(
    "⚡", "⭐", "❤️", "🏠", "📞", "✉️", "💬", "📷", "🎵", "🎬", "📍", "🚗",
    "✈️", "🛒", "📝", "📅", "⏰", "🔔", "🔦", "🔋", "📶", "🔒", "🔑", "💡",
    "🌙", "☀️", "🌧️", "🔥", "🎮", "📚", "💼", "💰", "🍔", "☕", "🏃", "💪",
    "🧠", "🤖", "🔍", "🌐", "📁", "🗑️", "✅", "🎯", "🚀", "🎁", "🧭", "🛠️"
)

fun Step.p(key: String, value: String) = copy(params = params + (key to value))

fun Shortcut.fresh(): Shortcut {
    val map = steps.associate { it.id to newId() }
    fun fix(s: String): String {
        var r = s
        for ((o, n) in map) r = r.replace("{{=$o}}", "{{=$n}}")
        return r
    }
    val now = System.currentTimeMillis()
    return copy(
        id = newUuid(), created = now, modified = now,
        steps = steps.map { st -> st.copy(id = map[st.id] ?: newId(), params = st.params.mapValues { fix(it.value) }) },
        questions = questions.map { it.copy(stepId = map[it.stepId] ?: it.stepId) }
    )
}

// ---------------- JSON ----------------

private fun JSONObject.strMap(key: String): Map<String, String> {
    val o = optJSONObject(key) ?: return emptyMap()
    return o.keys().asSequence().associateWith { o.optString(it) }
}

private fun Step.toJson() = JSONObject().put("id", id).put("type", type).put("params", JSONObject(params))
private fun stepFromJson(j: JSONObject) = Step(j.optString("id", newId()), j.getString("type"), j.strMap("params"))

private fun Shortcut.toJson(): JSONObject {
    val o = JSONObject()
        .put("id", id).put("name", name).put("color", color).put("glyph", glyph)
        .put("share", share).put("qs", qs).put("created", created).put("modified", modified)
    if (folderId != null) o.put("folderId", folderId)
    o.put("steps", JSONArray().also { a -> steps.forEach { a.put(it.toJson()) } })
    o.put("questions", JSONArray().also { a ->
        questions.forEach { a.put(JSONObject().put("stepId", it.stepId).put("key", it.key).put("text", it.text)) }
    })
    return o
}

private fun shortcutFromJson(j: JSONObject): Shortcut {
    val arr = j.optJSONArray("steps") ?: JSONArray()
    val qs = j.optJSONArray("questions") ?: JSONArray()
    return Shortcut(
        id = j.optString("id", newUuid()),
        name = j.optString("name", "Shortcut"),
        color = j.optInt("color", 6),
        glyph = j.optString("glyph", "⚡"),
        steps = (0 until arr.length()).map { stepFromJson(arr.getJSONObject(it)) },
        folderId = if (j.has("folderId")) j.optString("folderId") else null,
        share = j.optBoolean("share", false),
        qs = j.optBoolean("qs", false),
        created = j.optLong("created", System.currentTimeMillis()),
        modified = j.optLong("modified", System.currentTimeMillis()),
        questions = (0 until qs.length()).map {
            val q = qs.getJSONObject(it)
            ImportQuestion(q.optString("stepId"), q.optString("key"), q.optString("text"))
        }
    )
}

private fun Folder.toJson() = JSONObject().put("id", id).put("name", name).put("glyph", glyph).put("color", color)
private fun folderFromJson(j: JSONObject) = Folder(j.optString("id", newUuid()), j.optString("name", "Folder"), j.optString("glyph", "📁"), j.optInt("color", 6))

private fun Automation.toJson() = JSONObject().put("id", id).put("shortcutId", shortcutId).put("type", type)
    .put("params", JSONObject(params)).put("enabled", enabled).put("askBefore", askBefore)

private fun automationFromJson(j: JSONObject) = Automation(
    j.optString("id", newUuid()), j.optString("shortcutId"), j.optString("type"), j.strMap("params"),
    j.optBoolean("enabled", true), j.optBoolean("askBefore", true)
)

// ---------------- Store ----------------

object Store {
    val items = mutableStateListOf<Shortcut>()
    val folders = mutableStateListOf<Folder>()
    val automations = mutableStateListOf<Automation>()
    var layout by mutableStateOf("Grid")
    var sort by mutableStateOf("Last Modified")

    private var file: File? = null
    private var appCtx: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = Runnable { appCtx?.let { Integrations.refresh(it) } }

    fun load(ctx: Context) {
        if (file != null) return
        appCtx = ctx.applicationContext
        val f = File(ctx.filesDir, "library.json")
        file = f
        if (f.exists()) {
            try {
                val root = JSONObject(f.readText())
                root.optJSONArray("shortcuts")?.let { a -> for (i in 0 until a.length()) items.add(shortcutFromJson(a.getJSONObject(i))) }
                root.optJSONArray("folders")?.let { a -> for (i in 0 until a.length()) folders.add(folderFromJson(a.getJSONObject(i))) }
                root.optJSONArray("automations")?.let { a -> for (i in 0 until a.length()) automations.add(automationFromJson(a.getJSONObject(i))) }
                layout = root.optString("layout", "Grid")
                sort = root.optString("sort", "Last Modified")
            } catch (e: Exception) { /* corrupted file: start empty */ }
        } else {
            Gallery.starters.forEach { items.add(it.shortcut.fresh()) }
            save()
        }
    }

    fun save() {
        val root = JSONObject()
        root.put("shortcuts", JSONArray().also { a -> items.forEach { a.put(it.toJson()) } })
        root.put("folders", JSONArray().also { a -> folders.forEach { a.put(it.toJson()) } })
        root.put("automations", JSONArray().also { a -> automations.forEach { a.put(it.toJson()) } })
        root.put("layout", layout).put("sort", sort)
        try { file?.writeText(root.toString()) } catch (e: Exception) { }
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 1500)
    }

    fun get(id: String) = items.firstOrNull { it.id == id }
    fun byName(name: String) = items.firstOrNull { it.name.equals(name, ignoreCase = true) }

    fun add(s: Shortcut) { items.add(s); save() }

    fun update(s: Shortcut) {
        val i = items.indexOfFirst { it.id == s.id }
        if (i >= 0) { items[i] = s.copy(modified = System.currentTimeMillis()); save() }
    }

    fun delete(id: String) {
        items.removeAll { it.id == id }
        automations.removeAll { it.shortcutId == id }
        save()
    }

    fun duplicate(id: String) {
        val s = get(id) ?: return
        add(s.copy(name = s.name + " copy").fresh())
    }

    fun move(id: String, delta: Int) {
        val i = items.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= items.size) return
        val t = items[i]; items[i] = items[j]; items[j] = t
        save()
    }

    fun setLayout(v: String) { layout = v; save() }
    fun setSort(v: String) { sort = v; save() }

    fun addFolder(f: Folder) { folders.add(f); save() }
    fun renameFolder(id: String, name: String) {
        val i = folders.indexOfFirst { it.id == id }
        if (i >= 0) { folders[i] = folders[i].copy(name = name); save() }
    }
    fun deleteFolder(id: String) {
        for (i in items.indices) if (items[i].folderId == id) items[i] = items[i].copy(folderId = null)
        folders.removeAll { it.id == id }
        save()
    }

    fun addAutomation(a: Automation) { automations.add(a); save() }
    fun updateAutomation(a: Automation) {
        val i = automations.indexOfFirst { it.id == a.id }
        if (i >= 0) { automations[i] = a; save() }
    }
    fun deleteAutomation(id: String) { automations.removeAll { it.id == id }; save() }

    fun sorted(list: List<Shortcut>): List<Shortcut> = when (sort) {
        "Name" -> list.sortedBy { it.name.lowercase() }
        "Date Created" -> list.sortedByDescending { it.created }
        "Custom Order" -> list
        else -> list.sortedByDescending { it.modified }
    }

    // ---- Export / import ----
    fun exportOne(s: Shortcut): String =
        JSONObject().put("format", "android-shortcuts").put("version", 1).put("shortcut", s.toJson()).toString(2)

    fun exportAll(): String {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        return JSONObject().put("format", "android-shortcuts").put("version", 1).put("shortcuts", arr).toString(2)
    }

    /** Returns shortcuts parsed from text (not yet added). Throws on bad input. */
    fun parseImport(text: String): List<Shortcut> {
        val root = JSONObject(text.trim())
        val out = ArrayList<Shortcut>()
        root.optJSONObject("shortcut")?.let { out.add(shortcutFromJson(it).fresh()) }
        root.optJSONArray("shortcuts")?.let { a -> for (i in 0 until a.length()) out.add(shortcutFromJson(a.getJSONObject(i)).fresh()) }
        if (out.isEmpty() && root.has("steps")) out.add(shortcutFromJson(root).fresh())
        if (out.isEmpty()) throw IllegalArgumentException("No shortcuts found")
        return out
    }
}
