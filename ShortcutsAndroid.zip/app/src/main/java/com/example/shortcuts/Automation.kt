package com.example.shortcuts

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Calendar

/** Runs shortcuts with no screen: questions get their default answer, results become notifications. */
class HeadlessUi(private val ctx: Context) : RunUi {
    override suspend fun ask(prompt: String, default: String, numeric: Boolean): String? = default
    override suspend fun show(title: String, text: String) { postNotification(ctx, title, text) }
    override suspend fun choose(prompt: String, items: List<String>): String? = items.firstOrNull()
    override suspend fun confirm(title: String, message: String, showCancel: Boolean): Boolean = true
}

fun postNotification(ctx: Context, title: String, text: String) {
    try {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sc", "Shortcuts", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(ctx, "sc")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    } catch (e: Exception) { }
}

object AutomationRunner {
    /** Fires an automation: either asks first (notification) or runs right away. */
    suspend fun fire(ctx: Context, a: Automation) {
        val sc = Store.get(a.shortcutId) ?: return
        if (a.askBefore) {
            try {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel("ask", "Automation prompts", NotificationManager.IMPORTANCE_HIGH))
                val open = Intent(ctx, MainActivity::class.java)
                    .setAction(Intents.ACTION_RUN)
                    .putExtra(Intents.EXTRA_ID, sc.id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                val pi = PendingIntent.getActivity(
                    ctx, a.id.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val n = Notification.Builder(ctx, "ask")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Run \"${sc.name}\"?")
                    .setContentText(AutoCatalog.describe(a) + " — tap to run")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
                nm.notify(a.id.hashCode(), n)
            } catch (e: Exception) { }
        } else {
            try {
                Interpreter(ctx, HeadlessUi(ctx)).run(sc, null)
            } catch (e: Exception) {
                postNotification(ctx, "\"${sc.name}\" failed", e.message ?: e.toString())
            }
        }
    }
}

object AutomationScheduler {
    private val days = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    fun nextTime(a: Automation): Long {
        val h = (a.params["hour"]?.toIntOrNull() ?: 8).coerceIn(0, 23)
        val m = (a.params["minute"]?.toIntOrNull() ?: 0).coerceIn(0, 59)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        when (a.params["repeat"]) {
            "Weekly" -> {
                val target = days.indexOf(a.params["day"] ?: "Monday") + 1
                var guard = 0
                while ((cal.get(Calendar.DAY_OF_WEEK) != target || cal.timeInMillis <= now) && guard < 10) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                    guard++
                }
            }
            "Monthly" -> {
                val dom = a.params["dom"]?.toIntOrNull() ?: 1
                cal.set(Calendar.DAY_OF_MONTH, dom.coerceIn(1, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
                if (cal.timeInMillis <= now) {
                    cal.set(Calendar.DAY_OF_MONTH, 1)
                    cal.add(Calendar.MONTH, 1)
                    cal.set(Calendar.DAY_OF_MONTH, dom.coerceIn(1, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
                }
            }
            else -> if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun pending(ctx: Context, a: Automation): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, a.id.hashCode(),
            Intent(ctx, AlarmReceiver::class.java).putExtra("id", a.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun schedule(ctx: Context, a: Automation) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val t = nextTime(a)
            val pi = pending(ctx, a)
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
        } catch (e: Exception) { }
    }

    fun cancel(ctx: Context, a: Automation) {
        try { ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, a)) } catch (e: Exception) { }
    }

    fun rescheduleAll(ctx: Context) {
        for (a in Store.automations) {
            if (a.type != "time") continue
            if (a.enabled) schedule(ctx, a) else cancel(ctx, a)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        Store.load(ctx.applicationContext)
        val a = Store.automations.firstOrNull { it.id == id } ?: return
        AutomationScheduler.schedule(ctx, a)
        if (a.enabled) AutomationService.fire(ctx, a.id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Store.load(ctx.applicationContext)
        AutomationService.refresh(ctx)
    }
}

class AutomationService : Service() {

    companion object {
        const val ACTION_FIRE = "com.example.shortcuts.FIRE"
        const val ACTION_REFRESH = "com.example.shortcuts.REFRESH"

        private fun hasEvents() = Store.automations.any { it.enabled && it.type != "time" }

        fun fire(ctx: Context, id: String) {
            try {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, AutomationService::class.java).setAction(ACTION_FIRE).putExtra("id", id)
                )
            } catch (e: Exception) {
                // Could not start the service from the background: fall back to a direct run.
                val a = Store.automations.firstOrNull { it.id == id } ?: return
                CoroutineScope(SupervisorJob() + Dispatchers.Main).launch { AutomationRunner.fire(ctx.applicationContext, a) }
            }
        }

        fun refresh(ctx: Context) {
            try {
                if (hasEvents()) {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, AutomationService::class.java).setAction(ACTION_REFRESH))
                } else {
                    ctx.stopService(Intent(ctx, AutomationService::class.java))
                }
            } catch (e: Exception) { }
            AutomationScheduler.rescheduleAll(ctx)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var receiver: BroadcastReceiver? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var wifiRegisteredAt = 0L
    private val lastLevel = HashMap<String, Int>()
    private var running = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        Store.load(applicationContext)
        rebuild()
        if (intent?.action == ACTION_FIRE) {
            val id = intent.getStringExtra("id")
            val a = Store.automations.firstOrNull { it.id == id }
            if (a != null) trigger(a)
        }
        if (running == 0 && !hasEvents()) stopSelf()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("auto", "Automations", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "auto")
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("Shortcuts automations are active")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun trigger(a: Automation) {
        running++
        scope.launch {
            try {
                AutomationRunner.fire(applicationContext, a)
            } finally {
                running--
                if (running == 0 && !hasEvents()) stopSelf()
            }
        }
    }

    private fun rebuild() {
        receiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null
        netCb?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } catch (e: Exception) { }
        }
        netCb = null

        val active = Store.automations.filter { it.enabled && it.type != "time" }
        if (active.isEmpty()) return

        val filter = IntentFilter()
        for (a in active) {
            when (a.type) {
                "charger" -> { filter.addAction(Intent.ACTION_POWER_CONNECTED); filter.addAction(Intent.ACTION_POWER_DISCONNECTED) }
                "battery" -> filter.addAction(Intent.ACTION_BATTERY_CHANGED)
                "airplane" -> filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
                "bluetooth" -> { filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED); filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED) }
                "dnd" -> filter.addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
                "lowpower" -> filter.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                "headphones" -> filter.addAction(Intent.ACTION_HEADSET_PLUG)
                "unlock" -> filter.addAction(Intent.ACTION_USER_PRESENT)
            }
        }
        if (filter.countActions() > 0) {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) { handle(i) }
            }
            ContextCompat.registerReceiver(this, r, filter, ContextCompat.RECEIVER_EXPORTED)
            receiver = r
        }

        if (active.any { it.type == "wifi" }) {
            try {
                val cm = getSystemService(ConnectivityManager::class.java)
                val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
                wifiRegisteredAt = System.currentTimeMillis()
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) { wifiEvent("Connected") }
                    override fun onLost(network: Network) { wifiEvent("Disconnected") }
                }
                cm.registerNetworkCallback(req, cb)
                netCb = cb
            } catch (e: Exception) { }
        }
    }

    private fun wifiEvent(state: String) {
        if (System.currentTimeMillis() - wifiRegisteredAt < 3000) return
        scope.launch {
            for (a in Store.automations.filter { it.enabled && it.type == "wifi" && it.params["state"] == state }) trigger(a)
        }
    }

    private fun handle(i: Intent) {
        for (a in Store.automations.filter { it.enabled && it.type != "time" && it.type != "wifi" }) {
            if (matches(a, i)) trigger(a)
        }
    }

    private fun matches(a: Automation, i: Intent): Boolean {
        val st = a.params["state"] ?: ""
        return when (a.type) {
            "charger" -> (i.action == Intent.ACTION_POWER_CONNECTED && st == "Connected") ||
                (i.action == Intent.ACTION_POWER_DISCONNECTED && st == "Disconnected")
            "airplane" -> i.action == Intent.ACTION_AIRPLANE_MODE_CHANGED &&
                (i.getBooleanExtra("state", false) == (st == "On"))
            "bluetooth" -> (i.action == BluetoothDevice.ACTION_ACL_CONNECTED && st == "Connects") ||
                (i.action == BluetoothDevice.ACTION_ACL_DISCONNECTED && st == "Disconnects")
            "dnd" -> {
                val nm = getSystemService(NotificationManager::class.java)
                i.action == NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED &&
                    ((nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) == (st == "On"))
            }
            "lowpower" -> {
                val pm = getSystemService(PowerManager::class.java)
                i.action == PowerManager.ACTION_POWER_SAVE_MODE_CHANGED && (pm.isPowerSaveMode == (st == "On"))
            }
            "headphones" -> i.action == Intent.ACTION_HEADSET_PLUG &&
                ((i.getIntExtra("state", 0) == 1) == (st == "Plugged In"))
            "unlock" -> i.action == Intent.ACTION_USER_PRESENT
            "battery" -> if (i.action == Intent.ACTION_BATTERY_CHANGED) batteryCrossed(a, i) else false
            else -> false
        }
    }

    private fun batteryCrossed(a: Automation, i: Intent): Boolean {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return false
        val now = level * 100 / scale
        val prev = lastLevel[a.id] ?: now
        lastLevel[a.id] = now
        val th = a.params["level"]?.toIntOrNull() ?: 20
        return if (a.params["op"] == "rises above") prev < th && now >= th else prev > th && now <= th
    }

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        netCb?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } catch (e: Exception) { }
        }
        scope.cancel()
        super.onDestroy()
    }
}
