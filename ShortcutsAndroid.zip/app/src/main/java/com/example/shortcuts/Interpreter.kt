package com.example.shortcuts

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume

interface RunUi {
    suspend fun ask(prompt: String, default: String, numeric: Boolean): String?
    suspend fun show(title: String, text: String)
    suspend fun choose(prompt: String, items: List<String>): String?
    suspend fun confirm(title: String, message: String, showCancel: Boolean): Boolean
}

/** Thrown to end a shortcut early (Stop, Stop and Output, Cancel). */
class StopException(val output: Any?) : RuntimeException()

private class Loop(val items: List<Any?>) {
    var idx = 0
    var current: Any? = null
}

class Interpreter(private val ctx: Context, private val ui: RunUi, private val depth: Int = 0) {

    companion object { private var torch = false }

    private val vars = HashMap<String, Any?>()
    private val outputs = HashMap<String, Any?>()
    private var last: Any? = null
    private var input: Any? = null
    private val loops = HashMap<Int, Loop>()
    private val loopStack = ArrayList<Int>()
    private var askLabel = ""

    // ---------- variables ----------

    private suspend fun resolve(name0: String): Any? {
        val n = name0.trim()
        return when {
            n.startsWith("=") -> outputs[n.substring(1)]
            n.startsWith("@") -> vars[n.substring(1)]
            n == "Result" -> last
            n == "Clipboard" -> clip()
            n == "Current Date" -> isoNow()
            n == "Shortcut Input" -> input
            n == "Ask Each Time" -> ui.ask(askLabel, "", false) ?: throw StopException(null)
            n == "Repeat Item" -> loopStack.lastOrNull()?.let { loops[it]?.current }
            n == "Repeat Index" -> loopStack.lastOrNull()?.let { (loops[it]?.idx ?: 0).toDouble() }
            else -> vars[n]
        }
    }

    private suspend fun fill(s: String): String {
        if (!s.contains("{{")) return s
        val sb = StringBuilder()
        var pos = 0
        for (m in TokenRe.findAll(s)) {
            sb.append(s, pos, m.range.first)
            sb.append(str(resolve(m.groupValues[1])))
            pos = m.range.last + 1
        }
        sb.append(s, pos, s.length)
        return sb.toString()
    }

    /** If the whole text is one variable, keep its real type (list, dictionary, number…). */
    private suspend fun typed(s: String): Any? {
        val m = TokenRe.matchEntire(s.trim())
        return if (m != null) resolve(m.groupValues[1]) else fill(s)
    }

    // ---------- main loop ----------

    suspend fun run(sc: Shortcut, shortcutInput: Any? = null): Any? {
        if (depth > 8) throw IllegalStateException("Shortcuts are nested too deeply")
        input = shortcutInput
        val steps = sc.steps
        val n = steps.size

        val endAt = IntArray(n) { -1 }
        val elseAt = IntArray(n) { -1 }
        val startAt = IntArray(n) { -1 }
        val menuItems = HashMap<Int, MutableList<Int>>()
        val stack = ArrayList<Int>()
        for (i in 0 until n) {
            when (steps[i].type) {
                "if", "repeat", "repeat_each", "menu" -> { stack.add(i) }
                "else" -> { if (stack.isNotEmpty()) elseAt[stack[stack.size - 1]] = i }
                "menu_item" -> {
                    if (stack.isNotEmpty()) menuItems.getOrPut(stack[stack.size - 1]) { mutableListOf() }.add(i)
                }
                "endif", "endrepeat", "endmenu" -> {
                    if (stack.isNotEmpty()) {
                        val o = stack.removeAt(stack.size - 1)
                        endAt[o] = i
                        startAt[i] = o
                        if (elseAt[o] >= 0) endAt[elseAt[o]] = i
                        menuItems[o]?.forEach { endAt[it] = i }
                    }
                }
            }
        }

        var pc = 0
        var guard = 0
        try {
            while (pc in 0 until n) {
                if (++guard > 500000) throw IllegalStateException("Too many steps (possible infinite loop)")
                yield()
                val s = steps[pc]
                val d = Catalog.byType[s.type]
                var next = pc + 1
                var out: Any? = null
                var produced = false
                fun put(v: Any?) { out = v; produced = true }
                fun raw(k: String): String = s.params[k] ?: d?.params?.firstOrNull { it.key == k }?.def ?: ""
                fun label(k: String) = (d?.title ?: "") + " – " + (d?.params?.firstOrNull { it.key == k }?.label ?: k)
                suspend fun a(k: String): String { askLabel = label(k); return fill(raw(k)) }
                suspend fun t(k: String): Any? { askLabel = label(k); return typed(raw(k)) }
                val endNext = if (endAt[pc] >= 0) endAt[pc] + 1 else n

                when (s.type) {
                    // ----- control flow -----
                    "if" -> {
                        if (!cond(t("left"), raw("op"), a("right"))) {
                            next = if (elseAt[pc] >= 0) elseAt[pc] + 1 else endNext
                        }
                    }
                    "else", "menu_item" -> { next = endNext }
                    "endif", "endmenu", "comment" -> {}
                    "repeat", "repeat_each" -> {
                        val loop = loops.getOrPut(pc) {
                            loopStack.add(pc)
                            if (s.type == "repeat") {
                                val cnt = num(t("count")).toInt().coerceAtLeast(0)
                                Loop((1..cnt).map { it.toDouble() })
                            } else Loop(toList(t("input")))
                        }
                        if (loop.idx >= loop.items.size) {
                            loops.remove(pc)
                            loopStack.removeAll { it == pc }
                            next = endNext
                        } else {
                            loop.current = loop.items[loop.idx]
                            loop.idx++
                        }
                    }
                    "endrepeat" -> { if (startAt[pc] >= 0) next = startAt[pc] }
                    "menu" -> {
                        val items = menuItems[pc].orEmpty()
                        val titles = items.map { fill(steps[it].params["title"] ?: "") }
                        if (titles.isEmpty()) { next = endNext } else {
                            val choice = ui.choose(a("prompt"), titles) ?: throw StopException(null)
                            val idx = titles.indexOf(choice)
                            put(choice)
                            next = if (idx >= 0) items[idx] + 1 else endNext
                        }
                    }
                    "stop" -> throw StopException(last)
                    "output" -> throw StopException(t("output"))
                    "nothing" -> put(null)
                    "wait" -> delay(((num(a("seconds"))) * 1000).toLong().coerceIn(0L, 600000L))
                    "run_shortcut" -> {
                        val target = Store.byName(a("name")) ?: throw IllegalStateException("Shortcut not found: ${a("name")}")
                        put(Interpreter(ctx, ui, depth + 1).run(target, t("input")))
                    }

                    // ----- variables -----
                    "set_var" -> vars[a("name")] = t("value")
                    "add_var" -> {
                        val nm = a("name")
                        val cur = vars[nm]
                        val list = if (cur == null) ArrayList<Any?>() else ArrayList(toList(cur))
                        list.add(t("value"))
                        vars[nm] = list
                    }
                    "get_var" -> put(vars[a("name")])

                    // ----- prompts -----
                    "ask_input" -> {
                        val numeric = raw("type") == "Number"
                        val r = ui.ask(a("prompt"), a("default"), numeric) ?: throw StopException(null)
                        put(if (numeric) (r.toDoubleOrNull() ?: 0.0) else r)
                    }
                    "show_result" -> ui.show("Result", a("text"))
                    "alert" -> {
                        if (!ui.confirm(a("title"), a("message"), raw("cancel") == "Yes")) throw StopException(null)
                    }
                    "notification" -> notify(a("title"), a("body"))

                    // ----- lists & data -----
                    "list" -> put(a("items").split("\n").filter { it.isNotEmpty() })
                    "choose_list" -> {
                        val items = toList(t("input")).map { str(it) }
                        val choice = ui.choose(a("prompt"), items) ?: throw StopException(null)
                        put(choice)
                    }
                    "count" -> put(toList(t("input")).size.toDouble())
                    "get_item" -> {
                        val l = toList(t("input"))
                        val idx = when (raw("which")) {
                            "Last Item" -> l.size - 1
                            "Random Item" -> if (l.isEmpty()) -1 else (0 until l.size).random()
                            "Item At Index" -> num(a("index")).toInt() - 1
                            else -> 0
                        }
                        put(l.getOrNull(idx))
                    }
                    "filter_list" -> {
                        val l = toList(t("input"))
                        val v = a("value")
                        val op = raw("op")
                        put(l.filter { cond(it, op, v) })
                    }
                    "sort_list" -> {
                        val l = toList(t("input"))
                        put(when (raw("order")) {
                            "Z to A" -> l.sortedByDescending { str(it).lowercase() }
                            "Smallest First" -> l.sortedBy { num(it) }
                            "Biggest First" -> l.sortedByDescending { num(it) }
                            "Random" -> l.shuffled()
                            else -> l.sortedBy { str(it).lowercase() }
                        })
                    }
                    "dictionary" -> {
                        val m = LinkedHashMap<String, Any?>()
                        for (line in a("items").lines()) {
                            val i = line.indexOf(':')
                            if (i > 0) m[line.substring(0, i).trim()] = line.substring(i + 1).trim()
                        }
                        put(m)
                    }
                    "get_dict" -> {
                        val src = t("input")
                        val root = if (src is String) (parseJson(src) ?: src) else src
                        put(dig(root, a("key")))
                    }
                    "set_dict" -> {
                        val src = t("input")
                        val base = if (src is String) parseJson(src) else src
                        val m = LinkedHashMap<String, Any?>()
                        if (base is Map<*, *>) for ((k, v) in base) m[k.toString()] = v
                        m[a("key")] = t("value")
                        put(m)
                    }

                    // ----- text -----
                    "text" -> put(a("text"))
                    "combine" -> put(toList(t("input")).joinToString(nl(a("separator"))) { str(it) })
                    "split" -> put(str(t("input")).split(nl(a("separator"))))
                    "replace" -> put(a("input").replace(a("find"), a("with")))
                    "match" -> {
                        val text = a("input")
                        put(Regex(a("pattern")).findAll(text).map { it.value }.toList())
                    }
                    "case" -> {
                        val tx = a("input")
                        put(when (raw("mode")) {
                            "lowercase" -> tx.lowercase()
                            "Capitalize" -> tx.split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
                            else -> tx.uppercase()
                        })
                    }
                    "count_text" -> {
                        val tx = a("input")
                        put((when (raw("what")) {
                            "Words" -> tx.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size
                            "Lines" -> tx.lines().size
                            else -> tx.length
                        }).toDouble())
                    }
                    "url_encode" -> {
                        val tx = a("input")
                        put(if (raw("mode") == "Decode") URLDecoder.decode(tx, "UTF-8") else URLEncoder.encode(tx, "UTF-8"))
                    }
                    "base64" -> {
                        val tx = a("input")
                        put(
                            if (raw("mode") == "Decode") String(Base64.decode(tx, Base64.DEFAULT))
                            else Base64.encodeToString(tx.toByteArray(), Base64.NO_WRAP)
                        )
                    }
                    "speak" -> speak(a("text"))

                    // ----- numbers -----
                    "number" -> put(num(a("value")))
                    "math" -> {
                        val x = num(t("a"))
                        val y = num(a("b"))
                        put(when (raw("op")) {
                            "-" -> x - y
                            "×" -> x * y
                            "÷" -> x / y
                            "mod" -> x % y
                            else -> x + y
                        })
                    }
                    "expr" -> put(evalExpr(a("expression")))
                    "stats" -> {
                        val l = toList(t("input")).map { num(it) }
                        put(
                            if (l.isEmpty()) 0.0 else when (raw("op")) {
                                "Minimum" -> l.min()
                                "Maximum" -> l.max()
                                "Average" -> l.average()
                                "Median" -> {
                                    val sorted = l.sorted()
                                    if (sorted.size % 2 == 1) sorted[sorted.size / 2]
                                    else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2
                                }
                                else -> l.sum()
                            }
                        )
                    }
                    "random" -> {
                        val lo = num(a("min")).toInt()
                        val hi = num(a("max")).toInt()
                        put((minOf(lo, hi)..maxOf(lo, hi)).random().toDouble())
                    }
                    "round" -> {
                        val x = num(t("input"))
                        val p = num(a("places")).toInt().coerceIn(0, 10)
                        val f = Math.pow(10.0, p.toDouble())
                        put(when (raw("mode")) {
                            "Round Up" -> Math.ceil(x * f) / f
                            "Round Down" -> Math.floor(x * f) / f
                            else -> Math.round(x * f) / f
                        })
                    }

                    // ----- dates -----
                    "date" -> put(isoNow())
                    "format_date" -> put(formatDate(parseDate(a("input")) ?: Date(), raw("style"), a("custom")))
                    "adjust_date" -> {
                        val cal = Calendar.getInstance()
                        cal.time = parseDate(a("input")) ?: Date()
                        val amt = num(a("amount")).toInt() * (if (raw("op") == "Subtract") -1 else 1)
                        cal.add(
                            when (raw("unit")) {
                                "Minutes" -> Calendar.MINUTE
                                "Hours" -> Calendar.HOUR_OF_DAY
                                "Weeks" -> Calendar.WEEK_OF_YEAR
                                "Months" -> Calendar.MONTH
                                "Years" -> Calendar.YEAR
                                else -> Calendar.DAY_OF_YEAR
                            }, amt
                        )
                        put(isoFormat(cal.time))
                    }
                    "time_between" -> {
                        val d1 = parseDate(a("start")) ?: Date()
                        val d2 = parseDate(a("end")) ?: Date()
                        val ms = (d2.time - d1.time).toDouble()
                        put(ms / when (raw("unit")) {
                            "Minutes" -> 60000.0
                            "Hours" -> 3600000.0
                            "Weeks" -> 604800000.0
                            else -> 86400000.0
                        })
                    }

                    // ----- web -----
                    "open_url" -> start(Intent(Intent.ACTION_VIEW, Uri.parse(a("url"))))
                    "search_web" -> start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a("query")))))
                    "fetch_url" -> put(httpRequest(a("url"), raw("method"), a("headers"), raw("body_type"), a("body")))

                    // ----- device -----
                    "device_detail" -> put(deviceDetail(raw("detail")))
                    "clipboard_get" -> put(clip())
                    "clipboard_set" -> {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("text", a("text")))
                    }
                    "vibrate" -> vibrate(num(a("ms")).toLong().coerceIn(10L, 5000L))
                    "flashlight" -> flashlight(raw("state"))
                    "set_volume" -> setVolume(raw("stream"), num(a("level")).toInt().coerceIn(0, 100))
                    "set_ringer" -> setRinger(raw("mode"))
                    "open_settings" -> start(Intent(settingsAction(raw("page"))))

                    // ----- apps -----
                    "list_apps" -> put(launchableApps().map { it.first })
                    "open_app" -> {
                        val q = a("app").trim()
                        val pm = ctx.packageManager
                        val byLabel = launchableApps().firstOrNull { it.first.equals(q, true) }?.second
                        val i = pm.getLaunchIntentForPackage(byLabel ?: q)
                            ?: throw IllegalStateException("App not found: $q")
                        start(i)
                    }
                    "share_text" -> {
                        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a("text"))
                        start(Intent.createChooser(i, "Share"))
                    }
                    "call" -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a("number")))))
                    "sms" -> start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a("number")))).putExtra("sms_body", a("message")))
                    "email" -> start(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + a("to")))
                            .putExtra(Intent.EXTRA_SUBJECT, a("subject"))
                            .putExtra(Intent.EXTRA_TEXT, a("body"))
                    )
                    "maps" -> start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a("query")))))
                    "navigate" -> start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a("destination")))))
                    "timer" -> start(
                        Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, num(a("seconds")).toInt())
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    )
                    "alarm" -> start(
                        Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, num(a("hour")).toInt())
                            .putExtra(AlarmClock.EXTRA_MINUTES, num(a("minute")).toInt())
                            .putExtra(AlarmClock.EXTRA_MESSAGE, a("label"))
                    )
                    "add_event" -> {
                        val startMs = parseDate(a("start"))?.time ?: System.currentTimeMillis()
                        val endMs = parseDate(a("end"))?.time ?: (startMs + 3600000L)
                        start(
                            Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                                .putExtra(CalendarContract.Events.TITLE, a("title"))
                                .putExtra(CalendarContract.Events.EVENT_LOCATION, a("location"))
                                .putExtra(CalendarContract.Events.DESCRIPTION, a("notes"))
                                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMs)
                                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMs)
                        )
                    }
                    "add_contact" -> start(
                        Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
                            .putExtra(ContactsContract.Intents.Insert.NAME, a("name"))
                            .putExtra(ContactsContract.Intents.Insert.PHONE, a("phone"))
                            .putExtra(ContactsContract.Intents.Insert.EMAIL, a("email"))
                    )

                    // ----- files -----
                    "save_file" -> {
                        val f = shortcutFile(a("name"))
                        val content = a("content")
                        if (raw("mode") == "Append") f.appendText(content) else f.writeText(content)
                    }
                    "get_file" -> {
                        val f = shortcutFile(a("name"))
                        put(if (f.exists()) f.readText() else throw IllegalStateException("File not found: ${f.name}"))
                    }
                    "delete_file" -> shortcutFile(a("name")).delete()

                    else -> throw IllegalStateException("Unknown action: ${s.type}")
                }

                if (produced) {
                    outputs[s.id] = out
                    last = out
                }
                pc = next
            }
        } catch (e: StopException) {
            return e.output ?: last
        }
        return last
    }

    // ---------- helpers ----------

    private fun nl(s: String) = s.replace("\\n", "\n")

    private fun cond(l: Any?, op: String, r: String): Boolean {
        val ls = str(l)
        return when (op) {
            "is not" -> ls != r
            "contains" -> ls.contains(r, true)
            "does not contain" -> !ls.contains(r, true)
            "begins with" -> ls.startsWith(r, true)
            "ends with" -> ls.endsWith(r, true)
            "is greater than" -> num(l) > num(r)
            "is less than" -> num(l) < num(r)
            "has any value" -> ls.isNotEmpty()
            "has no value" -> ls.isEmpty()
            else -> ls == r || (ls.toDoubleOrNull() != null && ls.toDoubleOrNull() == r.toDoubleOrNull())
        }
    }

    private fun formatDate(d: Date, style: String, custom: String): String = when (style) {
        "Short" -> DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(d)
        "Long" -> DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.SHORT).format(d)
        "Full" -> DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT).format(d)
        "Date Only" -> DateFormat.getDateInstance(DateFormat.MEDIUM).format(d)
        "Time Only" -> DateFormat.getTimeInstance(DateFormat.SHORT).format(d)
        "ISO 8601" -> isoFormat(d)
        "Custom" -> SimpleDateFormat(custom, Locale.getDefault()).format(d)
        else -> DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(d)
    }

    private fun clip(): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        return if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(ctx).toString() else ""
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) }
        catch (e: ActivityNotFoundException) { throw IllegalStateException("No app can handle this action") }
    }

    private fun shortcutFile(name: String): File {
        val dir = File(ctx.filesDir, "Shortcuts")
        dir.mkdirs()
        val safe = name.replace("/", "_").replace("\\", "_").replace("..", "_").ifBlank { "file.txt" }
        return File(dir, safe)
    }

    private fun launchableApps(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .sortedBy { it.first.lowercase() }
    }

    private fun deviceDetail(which: String): Any? {
        val dm = ctx.resources.displayMetrics
        return when (which) {
            "Is Charging" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                bm.isCharging
            }
            "Device Model" -> Build.MODEL ?: ""
            "Manufacturer" -> Build.MANUFACTURER ?: ""
            "Android Version" -> Build.VERSION.RELEASE ?: ""
            "Screen Width" -> dm.widthPixels.toDouble()
            "Screen Height" -> dm.heightPixels.toDouble()
            "Language" -> Locale.getDefault().displayLanguage
            "Time Zone" -> TimeZone.getDefault().id
            else -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).toDouble()
            }
        }
    }

    private fun settingsAction(page: String): String = when (page) {
        "Wi-Fi" -> Settings.ACTION_WIFI_SETTINGS
        "Bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
        "Display" -> Settings.ACTION_DISPLAY_SETTINGS
        "Sound" -> Settings.ACTION_SOUND_SETTINGS
        "Battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        "Location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "Airplane Mode" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        "Apps" -> Settings.ACTION_APPLICATION_SETTINGS
        else -> Settings.ACTION_SETTINGS
    }

    private fun notify(title: String, body: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sc", "Shortcuts", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(ctx, "sc")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun flashlight(state: String) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: throw IllegalStateException("This device has no flashlight")
        torch = when (state) {
            "Off" -> false
            "Toggle" -> !torch
            else -> true
        }
        cm.setTorchMode(id, torch)
    }

    private fun setVolume(stream: String, level: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = when (stream) {
            "Ring" -> AudioManager.STREAM_RING
            "Alarm" -> AudioManager.STREAM_ALARM
            "Notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        try {
            am.setStreamVolume(st, (am.getStreamMaxVolume(st) * level / 100f).toInt(), 0)
        } catch (e: SecurityException) {
            throw IllegalStateException("Android needs Do Not Disturb access to change this volume")
        }
    }

    private fun setRinger(mode: String) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            am.ringerMode = when (mode) {
                "Vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                "Silent" -> AudioManager.RINGER_MODE_SILENT
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (e: SecurityException) {
            throw IllegalStateException("Android needs Do Not Disturb access to change the ringer mode")
        }
    }

    private suspend fun httpRequest(url: String, method: String, headers: String, bodyType: String, body: String): Any? =
        withContext(Dispatchers.IO) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.requestMethod = if (method.isBlank()) "GET" else method
            for (line in headers.lines()) {
                val i = line.indexOf(':')
                if (i > 0) c.setRequestProperty(line.substring(0, i).trim(), line.substring(i + 1).trim())
            }
            if (bodyType != "None" && c.requestMethod != "GET" && body.isNotEmpty()) {
                c.doOutput = true
                c.setRequestProperty(
                    "Content-Type",
                    when (bodyType) {
                        "JSON" -> "application/json"
                        "Form" -> "application/x-www-form-urlencoded"
                        else -> "text/plain"
                    }
                )
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code < 400) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            parseJson(text) ?: text
        }

    private suspend fun speak(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        var tts: TextToSpeech? = null
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        tts?.shutdown()
                        if (cont.isActive) cont.resume(Unit)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        tts?.shutdown()
                        if (cont.isActive) cont.resume(Unit)
                    }
                })
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sc-utt")
            } else {
                tts?.shutdown()
                if (cont.isActive) cont.resume(Unit)
            }
        }
        cont.invokeOnCancellation { tts?.shutdown() }
    }
}
